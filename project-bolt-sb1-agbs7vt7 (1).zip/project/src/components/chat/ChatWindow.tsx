import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, MoreVertical, Send, Smile, CheckCheck, Loader2, Users, LockKeyhole, Paperclip, Mic, Phone, Video, Search, Hexagon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { ConversationListItem, Message } from '@/types';
import { Avatar } from './Avatar';

interface Props { conversationId: string; summary: ConversationListItem | undefined; onBack: () => void; }

export function ChatWindow({ conversationId, summary, onBack }: Props) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const title = summary?.conv_type === 'group' ? summary.conv_name || 'Family room' : summary?.other_user_display_name || summary?.other_user_email || 'Conversation';
  const avatar = summary?.conv_type === 'group' ? summary.conv_avatar_url : summary?.other_user_avatar_url;
  useEffect(() => {
    let active = true;
    supabase.from('messages').select('*').eq('conversation_id', conversationId).order('created_at').then(({ data }) => { if (active) setMessages((data ?? []) as Message[]); });
    const channel = supabase.channel(`messages-${conversationId}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` }, (payload) => setMessages((current) => current.some((m) => m.id === payload.new.id) ? current : [...current, payload.new as Message])).subscribe();
    supabase.from('conversation_members').update({ last_read_at: new Date().toISOString() }).eq('conversation_id', conversationId).eq('user_id', user?.id ?? '');
    return () => { active = false; supabase.removeChannel(channel); };
  }, [conversationId, user?.id]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages.length]);
  const send = async () => { const text = body.trim(); if (!text || !user || sending) return; setSending(true); setBody(''); const { error } = await supabase.from('messages').insert({ conversation_id: conversationId, sender_id: user.id, body: text }); if (error) setBody(text); setSending(false); };
  return <section className="flex-1 min-w-0 flex flex-col h-full bg-nest-abyss honeycomb-pattern">
    <header className="h-[76px] px-4 md:px-6 glass hairline-b specular-top flex items-center gap-3 shrink-0">
      <button onClick={onBack} className="md:hidden p-2 -ml-2 rounded-full text-nest-zinc hover:text-nest-white hover:bg-nest-slate"><ArrowLeft className="w-5 h-5" /></button>
      <Avatar src={avatar} name={title} size="md" online={summary?.conv_type === 'direct'} />
      <div className="min-w-0 flex-1"><h2 className="font-display text-headline-sm text-nest-white truncate">{title}</h2><p className="text-label-md text-nest-zinc-dim flex items-center gap-1.5 mt-0.5">{summary?.conv_type === 'group' ? <><Users className="w-3 h-3" /> {summary.member_count} members</> : <><span className="w-1.5 h-1.5 bg-nest-honey rounded-full" /> Active now</>}</p></div>
      <div className="hidden sm:flex items-center gap-1"><button className="p-2.5 rounded-lg text-nest-zinc hover:text-nest-honey hover:bg-nest-slate"><Phone className="w-[18px] h-[18px]" /></button><button className="p-2.5 rounded-lg text-nest-zinc hover:text-nest-honey hover:bg-nest-slate"><Video className="w-[18px] h-[18px]" /></button><button className="p-2.5 rounded-lg text-nest-zinc hover:text-nest-honey hover:bg-nest-slate"><Search className="w-[18px] h-[18px]" /></button></div><button className="p-2.5 rounded-lg text-nest-zinc hover:text-nest-white hover:bg-nest-slate"><MoreVertical className="w-5 h-5" /></button>
    </header>
    <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-2">
      <div className="flex justify-center mb-8"><div className="flex items-center gap-2 glass hairline rounded-full px-3 py-1.5"><LockKeyhole className="w-3 h-3 text-nest-honey" /><span className="text-label-sm text-nest-zinc">Messages are private and encrypted</span></div></div>
      {messages.length === 0 && <div className="flex flex-col items-center justify-center py-20 text-center"><div className="w-16 h-16 hex-clip bg-nest-carbon hairline flex items-center justify-center mb-4"><Hexagon className="w-7 h-7 text-nest-honey/70" /></div><p className="font-display text-headline-sm text-nest-white-soft">Start the conversation</p><p className="text-body-sm text-nest-zinc-dim mt-2 max-w-xs">Say something warm. This space is just between you and {title}.</p></div>}
      {messages.map((message) => { const own = message.sender_id === user?.id; return <div key={message.id} className={`flex ${own ? 'justify-end' : 'justify-start'} animate-slide-up`}><div className={`max-w-[82%] sm:max-w-[65%] px-4 py-2.5 ${own ? 'bubble-outgoing rounded-[18px] rounded-br-[4px]' : 'bubble-incoming rounded-[18px] rounded-bl-[4px]'}`}><p className="text-body-lg text-nest-white-soft whitespace-pre-wrap break-words">{message.body}</p><div className="flex items-center justify-end gap-1.5 mt-1"><span className="text-label-sm text-nest-zinc-dim">{new Date(message.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span>{own && <CheckCheck className={`w-3.5 h-3.5 ${message.delivered_at ? 'text-nest-honey' : 'text-nest-zinc-dim'}`} />}</div></div></div>; })}<div ref={endRef} />
    </div>
    <div className="px-3 md:px-6 pb-4 pt-2 shrink-0"><div className="max-w-4xl mx-auto flex items-center gap-2 glass-input hairline-bright rounded-2xl px-2 py-2 specular-top"><button className="p-2 text-nest-zinc hover:text-nest-honey transition-colors"><Paperclip className="w-5 h-5" /></button><button className="hidden sm:block p-2 text-nest-zinc hover:text-nest-honey transition-colors"><Smile className="w-5 h-5" /></button><input value={body} onChange={(e) => setBody(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder="Write a message..." className="flex-1 bg-transparent px-2 py-2 text-body-md text-nest-white outline-none placeholder:text-nest-zinc-dim" /><button className="p-2 text-nest-zinc hover:text-nest-honey transition-colors"><Mic className="w-5 h-5" /></button><button onClick={send} disabled={!body.trim() || sending} className="w-10 h-10 rounded-xl bg-nest-honey hover:bg-nest-honey-dim disabled:opacity-30 text-nest-void flex items-center justify-center transition-all honey-glow">{sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}</button></div></div>
  </section>;
}
